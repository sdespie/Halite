from time import gmtime, strftime


class Utils:

    def print_log(self, text, file):
        if False:
            file.write(text + "\n")
